import java.util.Random;
import java.util.Scanner;
 
public class TypeRacer {
 
     
 
    private static Scanner reader;
 
    public static void main(String[] args) {
         
        {
          game();
        }
    }
 
 
    public static void game() {
        int maxlength = 5;
        final String chars = "abcdefghijklmnopqrstuvwxyz";
        String word = "";
        while(word.length() < maxlength){
            Random rand = new Random();
            int x = rand.nextInt(26) ;
            word = word + chars.charAt(x);
        }
            System.out.println("PARASYK: " + word);
            Scanner reader = new Scanner(System.in);  
            String answer = reader.nextLine(); 
            if(answer.equals(word) ) System.out.println("TEISINGAI");
            else System.out.println("NETEISINGAI");
        }
    }
